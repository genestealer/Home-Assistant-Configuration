python -m homeassistant --open-ui
pause
