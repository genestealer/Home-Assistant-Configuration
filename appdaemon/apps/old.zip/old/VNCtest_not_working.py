# init_commands: []
# python_packages:
#   - asyncvnc
#   - Pillow
# system_packages:
#   - jpeg
#   - tiff
# log_level: info



import hassapi as hass
import asyncio, asyncvnc
from PIL import Image

class vnctest(hass.Hass):



    def initialize(self):
    
        self.log("Start VNC Test")

        try:
            self.log("VNC Connect")
            # async def run_client():
            # async with asyncvnc.connect('192.168.3.11', password='engineer') as client:
            #     print(client)
            #     self.log(client)
            #     client.keyboard.write('hi there!')
            async def run_client():
              async with asyncvnc.connect('192.168.3.11', 'engineer') as client:
                  client.keyboard.write('hi there!')
                  # Request a video update
                  client.video.refresh()

                    # # Handle packets until Ctrl-C'd
                    # while True:
                    #     try:
                    #         update = await client.read()
                    #         print(update)
                    #     except KeyboardInterrupt:
                    #         break

                  # Retrieve pixels as a 3D numpy array
                  pixels = client.video.as_rgba()

                  # Save as PNG using PIL/pillow
                  image = Image.fromarray(pixels)
                  image.save('/appdaemon/apps/temp.png')
                  
                  self.log("VNC Connected")
        except TimeoutError:
            self.log("Timeout when connecting VNC")





    